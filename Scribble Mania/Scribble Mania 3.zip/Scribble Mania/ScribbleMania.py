import sys, pygame
from pygame.locals import *
import os, math, random
from vector2D import Vec2d


class splashScreen:

    def __init__(self):
        pygame.init()
        pygame.display.set_caption('Scribble Mania!')
        self.BLACK = 0,0,0
        self.WHITE = 255,255,255
        self.RED = (200,0,0)
        self.light_red = (255,0,0)
        self.YELLOW = (200,200,0)
        self.light_yellow = (255,255,0)
        self.GREEN = (34,177,76)
        self.light_green = (0,255,0)
        self.BLUE = (0,0,128)
        self.light_blue = (0,255,255)

        self.QUIT = False
        self.mousebutton = None
        self.mousedown = False
        self.mouse_buttons = ["Left Button","Middle Button","Right Button","Wheel Up","Wheel Down"]

        self.smallfont = pygame.font.SysFont("comicsansms", 25)
        self.medfont = pygame.font.SysFont("comicsansms", 50)
        self.largefont = pygame.font.SysFont("comicsansms", 85)

        self.clock = pygame.time.Clock()

        #initialize system
        self.initialize()

       
    def initialize(self):

        #Setup the pygame screen
        self.screen_width = 1300
        self.screen_height = 700
        self.screen_size = (self.screen_width, self.screen_height)    
        self.screen = pygame.display.set_mode(self.screen_size)
        
        #setup a generic drawing surface/canvas
        self.canvas = pygame.Surface((self.screen_width, self.screen_height))
        
        #load all the images
        self.bg = pygame.image.load("image/parallaxbg.jpg")
        self.playIcon = pygame.image.load("image/playbutton.png")
        self.vsIcon = pygame.image.load("image/vsbutton.png")
        self.settingIcon = pygame.image.load("image/settingButton.png")
        self.downloadIcon = pygame.image.load("image/DLbutton.png")
        self.titleIcon = pygame.image.load("image/title.png")
        self.quitIcon = pygame.image.load("image/exit.png")
        self.backIcon = pygame.image.load("image/back.png")
        
        #create Buttons 
        self.play_button = pygame.transform.scale(self.playIcon, (180,180))
        self.vs_button = pygame.transform.scale(self.vsIcon, (215, 215))
        self.setting_button = pygame.transform.scale(self.settingIcon, (80, 80))
        self.download_button = pygame.transform.scale(self.downloadIcon, (80, 80))
        self.quit_button = pygame.transform.scale(self.quitIcon,(80,80))
        self.back_button = pygame.transform.scale(self.backIcon,(80,80))
        
    

    def mouse_handler(self,event):

        if event.type == pygame.MOUSEBUTTONDOWN:
            self.mousedown = True
            self.mousebutton = event.button  
        elif event.type == pygame.MOUSEBUTTONUP:
            self.mousedown = False
            self.mousebutton = event.button

        self.mouseX, self.mouseY = pygame.mouse.get_pos()
 
        self.show_mousestate()


    def show_mousestate(self):
        """Show the mouse position and button press on the screen"""
        if self.mousebutton and self.mousedown:
            info = "Mouse: "+str(self.mouse_buttons[self.mousebutton-1])
        else:
            info = "Mouse: "
        info += "X= "+str(self.mouseX)+" Y: "+str(self.mouseY)

        #NB: for now we clear the canvas with black
        self.canvas.fill(self.BLACK)

        #load font and blit to canvas
        font = pygame.font.Font(None, 20)        
        textimg = font.render(info, 1, self.WHITE)
        self.canvas.blit(textimg, (10, 10))


    def draw(self):
        """We use a generic surface / Canvas onto which we draw anything
           Then we blit this canvas onto the display screen"""
        self.screen.blit(self.bg, (0, 0))

                #buttons are here
        self.button("play", 490,590,100,100, self.GREEN, self.light_green, action="play")
        self.button("vs", 818,588,103,103, self.YELLOW, self.light_yellow, action="vs")
        self.button("s", 65,560,45,45, self.YELLOW, self.light_yellow, action="setting")
        self.button("d", 65,460,45,45, self.YELLOW, self.light_yellow, action="download")
        self.button("quit", 1240,540,45,45, self.RED, self.light_red, action ="quit")
        
        self.screen.blit(self.play_button, (400, 500))
        self.screen.blit(self.vs_button, (710, 480))
        self.screen.blit(self.setting_button, (25, 520))
        self.screen.blit(self.download_button, (25, 420))
        self.screen.blit(self.titleIcon, (120,-80))
        self.screen.blit(self.quit_button, (1200,500))
        
        

    def button(self, text, x, y, width, height, inactive_color, active_color, action = None):
        cur = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        
        if(abs(cur[0]-x)<width and abs(cur[1]-y)<height):
        #if x + width > cur[0] > x-width and y + height > cur[1] > y-height:#rectangle
            pygame.draw.circle(self.screen, active_color, (x,y), width)
            
            if click[0] == 1 and action != None:
                if action == "quit":
                    pygame.quit()
                    quit()

                if action == "vs":
                    
                    print("This is vs")

                if action == "play":
                    mygame = gameMode()
                    mygame.run()
                    print("This is play")
                
                if action == "setting":
                    self.game_setting()
                    print("This setting")

                if action == "download":
                    print("This is download")

                if action == "backFromSetting":
                    print("This is back")
                    myWelcomScreen = splashScreen()
                    myWelcomScreen.run()

        else:
            pygame.draw.circle(self.screen, inactive_color, (x,y), width)

        self.text_to_button(text,self.BLACK,x,y,width,height)

    def text_objects(self, text, color,size = "small"):

        if size == "small":
            textSurface = self.smallfont.render(text, True, color)
        if size == "medium":
            textSurface = self.medfont.render(text, True, color)
        if size == "large":
            textSurface = self.largefont.render(text, True, color)

        return textSurface, textSurface.get_rect()

    def text_to_button(self, msg, color, buttonx, buttony, buttonwidth, buttonheight, size = "small"):
        textSurf, textRect = self.text_objects(msg,color,size)
        textRect.center = (buttonx, buttony)
        self.screen.blit(textSurf, textRect)

    def message_to_screen(self,msg,color, y_displace = 0, size = "small"):
        textSurf, textRect = self.text_objects(msg,color,size)
        textRect.center = (int(1300 / 2), int(700 / 2)+y_displace)
        self.screen.blit(textSurf, textRect)
    

    def game_setting(self):

        gcont = True

        while gcont:
            for event in pygame.event.get():
                    #print(event)
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        quit()


            self.screen.fill(self.WHITE)
            self.message_to_screen("Controls",self.GREEN,-100,size="large")
            self.message_to_screen("Draw Anything on Canvas to Finish the Task",self.BLACK,-30)
            self.message_to_screen("Goal 1: Find a solution with less time",self.BLACK,10)
            self.message_to_screen("Goal 2: Find a solution with less shapes",self.BLACK,50)
            
            self.button("back", 65,650,46,46, self.BLUE, self.light_blue, action="backFromSetting")
            self.screen.blit(self.back_button, (25, 610))

            pygame.display.update()

            self.clock.tick(15)

    def run(self):
        """This method provides the main application loop.
           It continues to run until either the ESC key is pressed
           or the window is closed
        """
        while True:
            
            events = pygame.event.get()
            for e in events:
                #pass event onto mouse handler only if something happens
                self.mouse_handler(e)
                

                #Set quit state when window is closed
                if e.type == pygame.QUIT :
                    self.QUIT = True
                if e.type == KEYDOWN:
                    #Set quit state on Esc key press
                    if e.key == K_ESCAPE:
                        self.QUIT = True
                                    
            if self.QUIT:
                #Exit pygame gracefully
                pygame.quit()
                sys.exit(0)

            #Process any drawing that needs to be done
            self.draw()

            #flip the display
            pygame.display.flip()

class gameMode:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption('Level 1')

        self.draw_on = False
        self.last_pos = (0, 0)
        self.color = (255, 128, 0)
        #The brush size is defined here
        self.radius = 10
        self.speed = 10
        self.gravity = 0.3
        self.linePosList = dict() #this is list of all shapes
        self.my_particles = []
        self.shapeKey = -2 


        self.initialize()
        self.clock = pygame.time.Clock()

    def initialize(self):
        #Setup the pygame screen
        self.screen_width = 1300
        self.screen_height = 700
        self.screen_size = (self.screen_width, self.screen_height)    
        self.screen = pygame.display.set_mode(self.screen_size)

        #load all the images
        self.paperbg = pygame.image.load("image/paperbg.jpg")
        
        #setup a generic drawing surface/canvas
        self.canvas = pygame.Surface((self.screen_width, self.screen_height))
        self.draw()

    def draw(self):

        self.screen.blit(self.paperbg, (160,75))
 
        myfont = pygame.font.SysFont("Impact", 75)
        label = myfont.render("Draw your own shapes!", 1, (255,255,255))
        self.screen.blit(label, (280, -1))



    def roundline(self,srf, color, start, end, radius=1):
        dx = end[0]-start[0]
        dy = end[1]-start[1]
        distance = int(max(abs(dx), abs(dy)))
        for i in range(distance):
            x = int(start[0]+float(i)/distance*dx)
            y = int(start[1]+float(i)/distance*dy)
            pygame.draw.circle(srf, color, (x, y), radius)

    def run(self):
        env = Environment(1300,675)
        try:
            while True:
                for e in pygame.event.get():
                    if e.type == pygame.QUIT:  
                        raise StopIteration
                    
                    #drawing area boundry [(171, 109), (1183, 112), (168, 661), (1182, 661)]                    
                    # if (e.pos[0]> 170 and e.pos[0] < 1180) and (e.pos[1] > 110 and e.pos[1] < 660):
                    if e.type == pygame.MOUSEBUTTONDOWN:
                        color = (random.randrange(256), random.randrange(256), random.randrange(256))
                        if (e.pos[0]> 150 and e.pos[0] < 1150) and (e.pos[1] > 75 and e.pos[1] < 665):
                            pygame.draw.circle(self.screen, color, e.pos, self.radius)
                            self.linePosList[self.shapeKey] = list(e.pos)
                            selected_particle = env.findParticle(e.pos[0], e.pos[1])
                            draw_on = True
                        else:
                            draw_on = False
                    if e.type == pygame.MOUSEBUTTONUP:#finished drawing one shape
                        selected_particle = None
                        if(len(self.linePosList)!=0):
                            if(len(self.linePosList[self.shapeKey])==2): #when it's a dot
                                #create a particle object here
                                #addParticles(self, x, y, size, color):
                                env.addParticles(self.linePosList[self.shapeKey][0],self.linePosList[self.shapeKey][1], self.radius, color)
                                selected_particle = None
                                running = True

                            elif(len(self.linePosList[self.shapeKey])>2): #when it's a shape
                                #create a curve object here
                                #addCurves(self, listOfParticles, size, color)
                                env.addCurves(self.linePosList[self.shapeKey],self.radius, color)
                                selected_particle = None
                                running = True
                            
                        self.shapeKey += 1
                        draw_on = False
                        print(self.linePosList) #checking if all the shapes are stored properly

                    if e.type == pygame.MOUSEMOTION:
                        if draw_on:
                            if (e.pos[0]> 150 and e.pos[0] < 1150) and (e.pos[1] > 75 and e.pos[1] < 665):
                                self.linePosList[self.shapeKey] += list(e.pos)
                                pygame.draw.circle(self.screen, color, e.pos, self.radius)
                                self.roundline(self.screen, color, e.pos, last_pos, self.radius)
                        last_pos = e.pos

                if selected_particle:
                    draw_on = False
                    selected_particle.mouseMove(e.pos[0], e.pos[1])

                env.update()
                self.screen.blit(self.paperbg, (160,75))

                tree = Quadtree(0, pygame.Rect(0,0,1300,700), env.particles)#creates trunk of quadtree
                tree.update(self.screen)#updates trunk and begins recursive process for collision testing

                #self.screen.fill(env.colour)

                for p in env.particles:
                    pygame.draw.circle(self.screen, p.colour, (int(p.x), int(p.y)), p.size, p.thickness)
                    #self.clock.tick(40)
                
                for c in env.curves:
                    for i in range(1,len(c.x)):
                        self.roundline(self.screen, c.colour, (c.x[i],c.y[i]),(c.x[i-1],c.y[i-1]), self.radius)

                
                pygame.display.flip()
            
 

        except StopIteration:
            pass

##################################################################
########### Following is the code for a particle class ###########
##################################################################

def addVectors(angle1, length1, angle2, length2):
    """ Returns the sum of two vectors """
    
    x  = math.sin(angle1) * length1 + math.sin(angle2) * length2
    y  = math.cos(angle1) * length1 + math.cos(angle2) * length2
    
    angle  = 0.5 * math.pi - math.atan2(y, x)
    length = math.hypot(x, y)

    return (angle, length)

def collide(p1, p2):
    """ Tests whether two particles overlap
        If they do, make them bounce
        i.e. update their angle, speed and position """
    
    dx = p1.x - p2.x
    dy = p1.y - p2.y
    
    dist = math.hypot(dx, dy)
    if dist < p1.size + p2.size:
        angle = math.atan2(dy, dx) + 0.5 * math.pi
        total_mass = p1.mass + p2.mass

        (p1.angle, p1.speed) = addVectors(p1.angle, p1.speed*(p1.mass-p2.mass)/total_mass, angle, 2*p2.speed*p2.mass/total_mass)
        (p2.angle, p2.speed) = addVectors(p2.angle, p2.speed*(p2.mass-p1.mass)/total_mass, angle+math.pi, 2*p1.speed*p1.mass/total_mass)
        elasticity = p1.elasticity * p2.elasticity
        p1.speed *= elasticity
        p2.speed *= elasticity

        overlap = 0.5*(p1.size + p2.size - dist+1)
        p1.x += math.sin(angle)*overlap
        p1.y -= math.cos(angle)*overlap
        p2.x -= math.sin(angle)*overlap
        p2.y += math.cos(angle)*overlap



def collideCurve(c1 , c2):
    """ Tests whether two curves overlap
        If they do, make them bounce
        i.e. update their angle, speed and position """
    xShapeLength = max(len(c1.x),len(c2.x))
    yShapeLength = max(len(c1.y),len(c2.y))
    dx = [0.0] * xShapeLength
    dy = [0.0] * yShapeLength
    
    if(len(c1.x) > len(c2.x)):
        for i in range(len(c1.x)):
            if(i >= len(c2.x)):
                dx[i] = 0
            else:
                dx[i] = c1.x[i] - c2.x[i] #long and short crash
                
    elif(len(c1.x)< len(c2.x)):
        for i in range(len(c2.x)):
            if(i >= len(c1.x)):
                dx[i] = 0 
            else:
                dx[i] = c1.x[i] - c2.x[i] #short and long crash
                
    if(len(c1.y) > len(c2.y)):
        for i in range(len(c1.y)):
            if(i < len(c2.y)):
                dy[i] = c1.y[i] - c2.y[i]
            else:
                dy[i] =0

    elif(len(c1.y)< len(c2.y)):
        for i in range(len(c2.y)):
            if(i < len(c1.y)):
                dy[i] = c1.y[i] - c2.y[i]
            else:
                dy[i] = 0
    
    dist = [0.0] * len(dx)  
    
    for j in range(len(dx)):
        
        dist[j] = math.hypot(float(dx[j]), float(dy[j]))

    #replace with quadtree code

    # for k in range(len(dist)):
    #     if dist[k] < c1.size + c2.size: #should be replaced with the quadTree algorithm
    #         for j in range(len(dx)):
    #             angle = math.atan2(dy[j], dx[j]) + 0.5 * math.pi
    #             total_mass = c1.mass + c2.mass

    #             (c1.angle, c1.speed) = addVectors( c1.angle , c1.speed*(c1.mass-c2.mass)/total_mass ,     angle    , 2*c2.speed*c2.mass/total_mass)
    #             (c2.angle, c2.speed) = addVectors( c2.angle , c2.speed*(c2.mass-c1.mass)/total_mass , angle+math.pi, 2*c1.speed*c1.mass/total_mass)
    #             elasticity = c1.elasticity * c2.elasticity
    #             c1.speed *= elasticity
    #             c2.speed *= elasticity

    #             overlap = 0.5*(c1.size + c2.size - dist[k]+1)
    #             for i in range(len(c1.x)):
    #                 c1.x[i] += math.sin(angle)*overlap
    #                 c1.y[i] -= math.cos(angle)*overlap
    #             for i in range(len(c2.x)):
    #                 c2.x[i] -= math.sin(angle)*overlap
    #                 c2.y[i] += math.cos(angle)*overlap


def PcollideC(p,c):
    #this part requires usage of quadTree
    pass

class Particle:
    """ A circular object with a velocity, size and mass """
    
    def __init__(self, x, y, size, mass=1):
        self.x = x
        self.y = y
        self.size = size
        self.colour = (0, 0, 255)
        self.thickness = 0
        self.speed = 0
        self.angle = 0
        self.mass = mass
        self.drag = 1
        self.elasticity = 0.7
        
    def get_rect(self):
        '''Returns quadtree rect object'''
        return self.rect


    def move(self):
        """ Update position based on speed, angle
            Update speed based on drag """

        (self.angle, self.speed) = addVectors(self.angle, self.speed, math.pi, 0.05)
        self.x += math.sin(self.angle) * self.speed
        self.y -= math.cos(self.angle) * self.speed
        self.speed *= self.drag
        
    def mouseMove(self, x, y):
        """ Change angle and speed to move towards a given point """

        dx = x - self.x
        dy = y - self.y
        self.angle = 0.5*math.pi + math.atan2(dy, dx)
        self.speed = math.hypot(dx, dy) * 0.1

class Curve:
    """ A unregular shape defined by the user's brush with a velocity, size and mass """

    def __init__(self, listOfParticles, size, mass = 2):
        self.x = []
        self.y = []
        for i in range(0,len(listOfParticles),2):
            self.x.append(listOfParticles[i])
        for j in range(1,len(listOfParticles),2):
            self.y.append(listOfParticles[j])
            
        self.size = size
        self.colour = (0, 0, 255)
        self.thickness = 0
        self.speed = 0
        self.angle = 0
        self.mass = mass
        self.drag = 1
        self.elasticity = 0.7
        self.listOfParticles = listOfParticles

    def move(self):
        """ Update position based on speed, angle
            Update speed based on drag """

        (self.angle, self.speed) = addVectors(self.angle, self.speed, math.pi, 0.05)

        for i in range(len(self.x)):
            self.x[i] += math.sin(self.angle) * self.speed
        for j in range(len(self.y)):
            self.y[j] -= math.cos(self.angle) * self.speed

        self.speed *= self.drag
        
    def mouseMove(self, x, y):
        """ Change angle and speed to move towards a given point """
        
        xShapeLength = max(len(c1.x),len(c2.x))
        yShapeLength = max(len(c1.y),len(c2.y))
        dx = [0.0] * xShapeLength
        dy = [0.0] * yShapeLength

        for i in range(len(self.x)):
            dx[i] = (x - self.x[i])
        
        for j in range(len(self.y)):
            dy[j] = (y - self.y[j])

        for k in range(len(dx)):
            self.angle = 0.5*math.pi + math.atan2(dy[k], dx[k])
            self.speed = math.hypot(dy[k], dx[k]) * 0.1


class Environment:
    """ Defines the boundary of a simulation and its properties """
    
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.particles = []
        self.curves = []
        
        self.colour = (255,255,255)
        self.mass_of_air = 0.2
        self.elasticity = 0.4
        self.acceleration = None
        
    def addParticles(self, x, y, size, color):
        """ Add n particles with properties given by keyword arguments """
        mass = random.randint(100, 10000) #should be number of self.shapeKey * (size**2 * math.pi) / (1300*700)

        particle = Particle(x, y, size, mass)
        particle.speed = random.random()
        particle.angle = 0
        particle.colour = color
        particle.drag = (particle.mass/(particle.mass + self.mass_of_air)) ** particle.size

        self.particles.append(particle)

    def addCurves(self, listOfParticles, size, color):
        """ Add a curved unregular shape with properties given by the user's brush """
        mass = random.randint(100, 10000)

        curve = Curve(listOfParticles,size,mass)
        curve.speed = random.random()
        curve.angle = 0
        curve.colour = color
        curve.drag = (curve.mass/(curve.mass+ self.mass_of_air)) ** curve.size

        self.curves.append(curve)


    def get_rect(self):
        '''Returns particle rect object'''
        return self.rect

    def set_rect(self,particle):
        '''Sets particle rect object at current coordinates with side length 2*radius'''
        particle.rect = pygame.Rect(particle.x - particle.size, particle.y - particle.size, particle.size*2, particle.size*2)


    def update(self):
        """  Moves particles and tests for collisions with the walls and each other """
        
        for i, particle in enumerate(self.particles):
            particle.move()
            if self.acceleration:
                particle.accelerate(self.acceleration)
            self.bounce(particle)
            for particle2 in self.particles[i+1:]:
                collide(particle, particle2)
            self.set_rect(particle)

        for i, curve in enumerate(self.curves):
            curve.move()
            if self.acceleration:
                curve.accelerate(self.acceleration)
            self.interact(curve)
            for curve2 in self.curves[i+1:]:
                collideCurve(curve, curve2)


    def bounce(self, particle):
        """ Tests whether a particle has hit the boundary of the environment """
        
        if particle.x > self.width - particle.size:
            particle.x = 2*(self.width - particle.size) - particle.x
            particle.angle = - particle.angle
            particle.speed *= self.elasticity

        elif particle.x < particle.size:
            particle.x = 2*particle.size - particle.x
            particle.angle = - particle.angle
            particle.speed *= self.elasticity

        if particle.y > self.height - particle.size:
            particle.y = 2*(self.height - particle.size) - particle.y
            particle.angle = math.pi - particle.angle
            particle.speed *= self.elasticity

        elif particle.y < particle.size:
            particle.y = 2*particle.size - particle.y
            particle.angle = math.pi - particle.angle
            particle.speed *= self.elasticity

    def interact(self, curve):
        """ Tests whether a curve has hit the boundary of the environment """
        for i in range(len(curve.x)):
            if curve.x[i] > self.width - curve.size:
                curve.x[i] = 2*(self.width - curve.size) - curve.x[i]
                curve.angle = - curve.angle
                curve.speed *= self.elasticity

            elif curve.x[i] < curve.size:
                curve.x[i] = 2*curve.size - curve.x[i]
                curve.angle = - curve.angle
                curve.speed *= self.elasticity

        for j in range(len(curve.y)):
            if curve.y[j] > self.height - curve.size:
                curve.y[j] = 2*(self.height - curve.size) - curve.y[j]
                curve.angle = math.pi - curve.angle
                curve.speed *= self.elasticity

            elif curve.y[j] < curve.size:
                curve.y[j] = 2*curve.size - curve.y[j]
                curve.angle = math.pi - curve.angle
                # curve.speed *= self.elasticity

    def findParticle(self, x, y):
        """ Returns any particle that occupies position x, y """
        
        for particle in self.particles:
            if math.hypot(particle.x - x, particle.y - y) <= particle.size:
                return particle
        return None

def rect_quad_split(rect):
    '''Splits rect object into four smaller rect objects'''
    w=rect.width/2.0
    h=rect.height/2.0
    rl=[]
    rl.append(pygame.Rect(rect.left, rect.top, w, h))
    rl.append(pygame.Rect(rect.left+w, rect.top, w, h))
    rl.append(pygame.Rect(rect.left, rect.top+h, w, h))
    rl.append(pygame.Rect(rect.left+w, rect.top+h, w, h))
    return rl

class Quadtree(object):
    def __init__(self, level, rect, particles=[], color = (0,0,0)):
        '''Quadtree box at with a current level, rect, list of particles, and color(if displayed)
        level: set to zero for "trunk" of quadtree
        rect: should be entire display for "trunk" of quadtree
        particles: list of all particles for collision testing'''
        self.maxlevel = 4#max number of subdivisions
        self.level = level#current level of subdivision
        self.maxparticles = 3#max number of particles without subdivision
        self.rect = rect#pygame rect object
        self.particles = particles#list of particles
        self.color = color#color of box if displayed
        self.branches = []#empty list that is filled with four branches if subdivided
        self.displayTree = True#boolean to display quadtree boxes behind particles



    def get_rect(self):
        '''Returns quadtree rect object'''
        return self.rect

    def subdivide(self):
        '''Subdivides quadtree into four branches'''
        for rect in rect_quad_split(self.rect):
            branch = Quadtree(self.level+1, rect, [], (self.color[0]+30,self.color[1],self.color[2]))
            self.branches.append(branch)

    def add_particle(self, particle):
        '''Adds a particle to the list of particles inside quadtree box'''
        self.particles.append(particle)

    def subdivide_particles(self):
        '''Subdivides list of particles in current box to four branch boxes'''
        for particle in self.particles:
            for branch in self.branches:
                if branch.get_rect().colliderect(particle.get_rect()):
                    branch.add_particle(particle)

    def render(self, display):
        '''Displays quadtree box on the display surface given'''
        pygame.draw.rect(display, self.color, self.rect)

    def test_collisions(self):
        '''Tests for collisions between all particles in the particle list'''
        for i, particle in enumerate(self.particles):
            for particle2 in self.particles[i+1:]:
                collide(particle, particle2)
            
    def update(self, display):
        '''Updates the quadtree and begins recursive process of subdividing or collision testing'''
        if len(self.particles) > self.maxparticles and self.level <= self.maxlevel:
            self.subdivide()
            self.subdivide_particles()
            for branch in self.branches:
                branch.update(display)
        else:
            self.test_collisions()
            if self.displayTree:
                self.render(display)


if __name__ == "__main__":
    myWelcomScreen = splashScreen()
    myWelcomScreen.run()